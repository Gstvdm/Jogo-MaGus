WARNING:
Guides might use outdated tiles which might not be in the public domain!

Only use the tiles from the folders above. No editing or copying or implementing in your game recommended unless you are 100% certain about the creators and the rights.

Thanks :)